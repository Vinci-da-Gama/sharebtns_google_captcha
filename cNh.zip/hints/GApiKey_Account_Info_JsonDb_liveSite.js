csbengage GoogleMap API Key:
    project Name: tailored - google_Map
Api Key: AIzaSyBvKStK - vN_HNPb2VAijj032WY - 90 b4V9A


//////////////////
// Account Info //
//////////////////

Mobecom.co

kelin.liao @mobecom.co
Haha1969


mongolab
account name: lindsay
username: lohan
email: kelin @csbengage.com
password: Haha1979

database1 name: signin - login - story
username: sltu
password: abc123

Database2 name: signup - login - filter - compilelink - transclusion
Username: slfct
Password: abc123

Gmail:
    Postman use this one--postman username: hohoaspasia
veronica aspasia
veronicaaspasia @gmail.com
Haha1979


luluayawhite @gmail.com
Wawa - 6633 $

Heroku
name: luluwhite corap
password: Haha1979
email: veronicaaspasia @gmail.com
development language: NodeJs

name: ladish ishta
password: Hihi - 1979
email: luluayawhite @gmail.com
development language: NodeJs

GitHub:
    luluWhite
veronicaaspasia @gmail.com
Eaea - 1979

Bitbucket
kelin.liao @csbengage.com
Wawa - 1979 || Haha1984 || Haha1979


csbengage Jira
link: https: //csbgroup.atlassian.net
    Email: kelin @csbengage.com
username: Kelin
To login into Muulla Pj
Email: kelin @csbengage.com
Password: Haha1979
Or
Email: kelin.liao @csbengage.com
Password: Haha1979

Jira - jira
When you need confirm password
for login, the password is: Haha1984
When you are in SourceTree, you will use Haha1984 too.

http: //www.hongkiat.com/blog/creative-css-animations/
    http: //www.hongkiat.com/blog/css-text-effects/

    Trello
Email: kelin @csbengage.com
Oaoa - 1979

Slack:
    https: //slack.com/signin -- must login as team.
    I use this to build new team--veronicaaspasia @gmail.com
Haha1979
team - Domain: aohuaeyeshot.slack.com

Howabouteat
Fn: collin ln: collins email: kelin @csbengage.com pswd: Haha - 1979 mobile: +61406689837(be careful, it is real)

Suite 5.03, L5, 9 - 13 Young Street, Sydney(at Circular Quay)

weglot: https: //weglot.com/login 
    Email: veronicaaspasia @gmail.com
password: Haha - 1979
Weglot API Key: wg_cb3ba7cef7caea9b3a5fe2cde11f1d41
Website is on WordPress
1. Install the plugin named "Weglot Translate"
from WordPress repository
2. Go to the Weglot configuration page on your administration panel and configure the plugin by entering your API key wg_cb3ba7cef7caea9b3a5fe2cde11f1d41, the original language of your website and the languages you want to be available.
3. Save configuration and reload your webpage: The button to
switch language will appear at the bottom right of your page.
4. Edit / correct translations as you wish
Website is not on WordPress
Copy paste the following javascript code in your HTML page, just before your < /body> tag.

<
script type = "text/javascript"
src = "https://weglot.com/api/weglot.js" > < /script>  <
script >
    Weglot.setup({
        api_key: 'wg_cb3ba7cef7caea9b3a5fe2cde11f1d41',
        originalLanguage: 'fr',
        destinationLanguages: 'en,es',
    }); <
/script>
Put your original language in originalLanguage and the languages you want to be available in destinationLanguages

For instance,
if your website is in french, and you want it to be available in english and spanish, you will enter 'originalLanguage': 'fr'
and 'destinationLanguages': 'en,es'

Then, simply reload your webpage and it is done!

    apple ID
kelin @csbengage.com
Lulu - 1979
favourite children book— answer: 1001
first movie saw in cinema— answer: red star illidan
favourite sports team— answer: native girl
1973 / Feb / 17
5487
state: QLD
03 0452123698




//////////////////
// JSON Database//
//////////////////

Table Head: var headerAisle = “https: //api.myjson.com/bins/ty1b";
    Table Content(td): var contentsAisle = “https: //api.myjson.com/bins/5a2p3”;

        Tablb Accordion Header And template Url: “https: //api.myjson.com/bins/3zvab”
        Tablb Accordion Header,
        Description And Image Url: “https: //api.myjson.com/bins/4s297”


        //////////////
        // live-site//
        //////////////


        Ribs and Rumps: https: //rnrfdc.endlessrewards.com.au/
        ChatThai: https: //chatthai.endlessrewards.com.au/
        Hooters: https: //hooterspos.endlessrewards.com.au/
        Panarottis: https: //panarottisrewards.co.za/
        BodyShop: https: //bodyshopindsite.rewards.globalred.com.au/#/home
        Twc: https: //twc.endlessrewards.com.au/login?ReturnUrl=%2fadmin%2fWebTerminal 
        Shuuga: https: //shuugarewards.endlessrewards.com.au/ 
        Degani: https: //mydegani.com.au/
        Cellbration: https: //www.cellarbration.com.sg/