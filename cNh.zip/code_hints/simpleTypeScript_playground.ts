Here is playground -- cp and paste them to https://www.typescriptlang.org/play/index.html to see the result.
// This is basic class
class GreeterClass {
	greetToWhom: string;
	constructor(whom:string) {
		this.greetToWhom = whom;
	}
	doGreeting() {
		return `Hello, ${this.greetToWhom}.`;
	}
};

let personGreeting = new GreeterClass('WWWorld');

let button = document.createElement('button');
button.textContent = 'say Greeting';
button.onclick = function() {
	alert(personGreeting.doGreeting());
}

document.body.appendChild(button);

// Inheritance (extends)
class Mammal {
	constructor(public theName: string) {}
	moveDistance( distanceInMeters:number = 0 ) {
		return `Now, ${this.theName} distance of locomotion is: ${distanceInMeters}(m).`;
	}
}

class MammalKindOne extends Mammal {
	constructor(namek1:string) {
		super(namek1);
	}
	moveDistance(distanceInMeters = 5) {
		super.moveDistance(distanceInMeters);
	}
}

class MammalKind2 extends Mammal {
	constructor(namek2:string) {
		super(namek2);
	}
	moveKindTwo(distanceK2 = 7) {
		super.moveDistance(distanceK2);
	}
}

let oneMammal = new MammalKindOne('wuha_Name1');
let r1 = oneMammal.moveDistance();

let twoMammal:Mammal = new MammalKind2('wuha_Name2');
// have to use super class moveDistance method.
let r2 = twoMammal.moveDistance(34);

let db = document.body;
let oneDiv = document.createElement('div');
oneDiv.innerText = `r1 is: ${r1} and r2 is ${r2}.`;
db.appendChild(oneDiv);

console.log(`37 -- r1 is: ${r1} and r2 is ${r2}.`);

// Using Generics <T>
class GreetingClassTtype<T> {
	greetToWhom: T
	constructor(whom: T) {
		this.greetToWhom = whom;
	}
	doGreeting() {
		return `Greeting to ${this.greetToWhom}.`;
	}
}

let greeter = new GreetingClassTtype<string> ('_thisGuy');

let db = document.body;
let oneDev = document.createElement('div');
let btn = document.createElement('button');
btn.textContent = 'Greeting_Click';
db.appendChild(btn);
btn.onclick = function () {
	let s0 = greeter.doGreeting();
	oneDev.innerText = s0;
	db.appendChild(oneDev);
};

// Unions and Type Guide → make multiple types into one type variable
type NameOrNameAry = string | string[];
let greateName = ['WuhaName0', 'Name_1', '_Name2'];

function setupName() {
	let tq = String.fromCharCode(9775);
	let relayName = function (name: NameOrNameAry) {
		if(typeof name === 'string') { 
			return name;
		} else {
			return name.join(tq);
		}
	}
	let result = `Say Greeting to ${relayName(greateName)}.`;
	console.log('result is: '+result);
	return result;
}

let db = document.body;
let aDiv = document.createElement('div');
aDiv.innerText = setupName();
db.appendChild(aDiv);

