IndoneciaMoneyFormatService

webterminalapp.service('IndoneciaMoneyFormatService', [function(){
	this.reformatIndoneciaMoney = function (tensionObj) {
		var balanceValue = tensionObj;
		// This is a mockup number for testing
		// var balanceValue = '3775008.00';
		var moneyArr = [];
		var concatMoney = "";
		var ucComma = String.fromCharCode(44);
		var initValue = roundedThenRemoveDefaultDot(balanceValue);
		var initReverseValue = reverseDigitsStr(initValue);
		var origLength = initReverseValue.length;

		// if even else odd (origin length contains comma, so even is 020,00)
		if (origLength%2 === 0) {
			var midStr = formatMoney(initReverseValue, origLength, moneyArr, ucComma);
			var dotsCounter = 0;
			for (var i = 0; i < midStr.length; i++) {
				if (midStr[i] === ".") {
					dotsCounter+=1;
				}
			};

			var midLen = midStr.length - dotsCounter;
			var tempMoney = extraPartionPlusMidString(midLen, midStr, initReverseValue, ucComma);
			concatMoney = removeIfComaAtFirstPositionInString(tempMoney, ucComma);
			// moneyArr = [];
			return concatMoney;
		} else{
			var tempMoney = formatMoney(initReverseValue, origLength, moneyArr, ucComma);
			concatMoney = removeIfComaAtFirstPositionInString(tempMoney, ucComma);
			// moneyArr = [];
			return concatMoney;
		};
	};

	function roundedThenRemoveDefaultDot (stasisValue) {
		var roundValue = String(Math.round(stasisValue));
		var clearVal = roundValue.replace(".", "");
		return clearVal;
	};

	function reverseDigitsStr (balanceSpend) {
		var bsStr = balanceSpend.toString();
		var reverseSpend = bsStr.split("").reverse().join("");
		return reverseSpend;
	};

	function formatMoney (irv, magnitude, moyArr, comma) {
		var mArr = moyArr;
		var mediumStr = "";
		for (var i = 0; i <= magnitude; i++) {
			var posDivide = (i+1)/3;
			if (Number.isInteger(posDivide) && posDivide > 0) {
				var anchor = i-2;
				var elem = irv.substring(anchor, i+1);
				mArr.push(elem);
			}
		};
		mediumStr = mArr.join(comma);

		var elemNumbersLen = mArr.length *3;
		var irvLen = irv.length;
		if (elemNumbersLen === irvLen) {
			var stepFormatedMoney = reverseDigitsStr(mediumStr);
			return stepFormatedMoney;
		} else {
			var mysteryElem = irv.slice(elemNumbersLen);
			mArr.push(mysteryElem);
			var stepMediumStr = mArr.join(comma);
			var stepFormatedMoney = reverseDigitsStr(stepMediumStr);
			return stepFormatedMoney;
		}

	};

	function extraPartionPlusMidString (ml, ms, irv, comma) {
		var evenResult = "";
		var redundantSegment = "";
		var irvLen = irv.length;
		redundantSegment = irv.substring(ml, irvLen);
		evenResult = redundantSegment+comma+ms;
		return evenResult;
	};

	function removeIfComaAtFirstPositionInString(stringCloseToTheEnd, comma) {
		var sctte = stringCloseToTheEnd;
		if (sctte[0] === comma) {
			var retransimissionStr = "";

			if (sctte[1] !== '0') {
				// var retransimissionStr = sctte.slice(1);
				retransimissionStr = sctte.substr(1);
				return retransimissionStr;
			} else if(sctte[1] === '0' && sctte[2] !== '0') {
				// var retransimissionStr = sctte.slice(2);
				retransimissionStr = sctte.substr(2);
				return retransimissionStr;
			} else if(sctte[1] === '0' && sctte[2] === '0')  {
				// var retransimissionStr = sctte.slice(3);
				retransimissionStr = sctte.substr(3);
				return retransimissionStr;
			} else {
				// var retransimissionStr = sctte.slice(5);
				// Jumpover carma again, so not index 4, it is 5.
				retransimissionStr = sctte.substr(5);
				return retransimissionStr;
			}

		} else {
			return sctte;
		}
	};

}]);

